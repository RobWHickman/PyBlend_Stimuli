# -*- coding: utf-8 -*-
"""
Created on Tue Apr 18 15:02:33 2017

@author: robert
"""

"""
Generate the maps used to wrap onto planets for the Planet Blend python scripts
--------------------------------------------------------------------------------

Composed of three functions:
	draw_map is a function to use the noise module to generate a x by y image and fill each pixel with semi-random
	noise using snoise3. The height values are then converted into colours based on the values in the function.

	crop_map is a function to crop the large map generated randomly
	and then double an image back to back (for fitting around a sphere).

	create_map is a small function that ties the previous two together and iterates the production, saving
	each map to a defined folder as it is created

The draw_map function's snoise3 generator takes 4 main arguments:
	- frequency: how often the map repeates
		how small the "islands" it produces will be whilst conserving the amount of "land"
	- octaves: the frequency (not related to above) of the noise:
		every octave introduces more noise with double the grainyness of the last octave
		after 6 octaves this becomes mostly redundant and intensive
		how "un-smooth" the "islands" will be
	- multiplier: how biased the map will be towards extremes:
		if the map will be more "deep water" and "snow" (0,1), or more "grass" and "beaches" (~0.5)
	- addition: how biased the map will be towards higher values:
		if the map will have more "snow" or more "deep water"

Finally, the script produces a number of maps specified by "repeats" and which folder images
should be saved in

Latest version: 1.0.0 (April 21st, 2017)
"""
#import libraries
from noise import snoise3
from random import Random 
from PIL import Image
from os import path

#random number generator to get around any seeds
randomgen = Random()

#the default parameters to pass into the functions
random_seed = True
set_seed = 0.22081992

base_size = 4000
map_size = 1000

frequency = randomgen.gauss(270, 70)
octs = 6
multiplier = randomgen.gauss(1.5, 0.3)
addition = randomgen.gauss(0.8, 0.2)

maps = 1
output_folder = "/home/robert/Desktop/Summerfield Lab/My Code/Planet Code/Maps"

def draw_map(random_seed, set_seed, base_size, frequency, octs, multiplier, addition):
	#set the seed
	if random_seed:
		seed = randomgen.random()
	else:
		seed = set_seed

	#set up the image of x,y pixels
	#should be a square (will be doubled in y later by wrapping 2x images for sphere)
	img = Image.new('RGB', (base_size,base_size), "black")
	pixels = img.load()

	#colour every pixel based on snoise3 height map
	for y in range(img.size[0]):
		for x in range(img.size[1]):
			#the perlin noise from which the 'height' (ie. colour) is drawn
			n = snoise3(x/frequency, y/frequency, seed, octaves = octs) * multiplier + addition
			#colour the pixels
			if n < 0.000000000000000000000000001:
				pixels[y,x] = (255, 255, 255) #snow
			elif n >= 0.000000000000000000000000001 and n < 0.15:
				pixels[y,x] = (128, 128, 128) #rock
			elif n >= 0.15 and n < 0.5:
				pixels[y,x] = (34,139,34) #forest
			elif n >= 0.5 and n < 0.7:
				pixels[y,x] = (32, 160, 0) #grass
			elif n >= 0.7 and n < 0.75:
				pixels[y,x] = (240, 240, 64) #sand
			elif n >= 0.75 and n < 0.8:
				pixels[y,x] = (0, 128, 255) #shore
			elif n >= 0.8 and n < 0.95:
				pixels[y,x] = (0, 0, 255) #shallows
			else:
				pixels[y,x] = (0, 0, 128) #deeps
	return(img)
    		
def crop_map(map_size, image):
	#crop the original file to a size x size image
	crop_x = int(randomgen.random() * (base_size - map_size))
	crop_y = int(randomgen.random() * (base_size - map_size))
	img1 = image.crop(box = (crop_x, crop_y, crop_x + map_size, crop_y + map_size))

	#randomly rotate the image
	rotate_angle = randomgen.randint(0,3) * 90
	img1.rotate(rotate_angle)

	#create a mirror image to stitch around
	img2 = img1.transpose(Image.FLIP_LEFT_RIGHT)

	#create a new empty image and paste the two img back to back
	result_size = map_size * 2
	result = Image.new('RGB', (result_size, map_size))
	result.paste(im=img1, box=(0, 0))
	result.paste(im=img2, box=(map_size, 0))
	return result

def create_map(maps, output_folder):
	#create x many maps
	for repeat in range(maps):
		img = draw_map(random_seed, set_seed, base_size, frequency, octs, multiplier, addition)
		newmap = crop_map(map_size, img)

		#set where to output the map(s) to
		folder = output_folder
		file_name = "map"
		file_num = repeat
		file_ext = ".bmp"
		output_file  = path.join(folder, (file_name+ str(file_num)+ file_ext))

		#save each map as it is produced
		newmap.save(output_file)

#run it all
create_map(maps, output_folder)